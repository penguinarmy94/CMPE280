from django.apps import AppConfig


class AirqualityappConfig(AppConfig):
    name = 'AirQualityApp'
